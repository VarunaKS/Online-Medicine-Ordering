<?php
	
	extract($_GET);
	if($place=="BANGALORE")
	{echo"<span>";
		echo "9047382947";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9387465273";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9864739304";echo"</span>";echo "<br/>";
	}
	if($place=="BOMBAY")
	{echo"<span>";
		echo "9347382930";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9634728177";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9748872903";echo"</span>";echo "<br/>";
	}
	if($place=="CHENNAI")
	{echo"<span>";
		echo "8577799200";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "8476637289";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9029987389";echo"</span>";echo "<br/>";
	}
	if($place=="KOLKATA")
	{echo"<span>";
		echo "9928388468";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "8839889200";echo"</span>";
		echo "</br>";
		echo"<span>";
		echo "9773893762";echo"</span>";
		echo "<br/>";
	}
?>
<!DOCTYPE html>
<html>
<head><style>body{font-family: 'Open Sans', sans-serif;font-weight:bold;font-size:30px;
	background-color:#ffcc99;
	color:#C4421A;}
	#s{padding:5px;background-color:#6699cc;font-family: 'Open Sans', sans-serif;font-weight:bold;font-size:20px;color:#0000ff;}span{
	color:#6699cc;font-size:25px;}</style></head>
<form method="GET" action="contact.html">


<input id="s" type="submit" value="GO BACK TO HOME PAGE"/>
</form>
</html>