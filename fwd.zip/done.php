<?php
	session_start();
	extract($_GET);
	echo "YOUR RESPONSE HAS BEEN RECORDED. THANK YOU FOR YOUR INPUT.";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo"WE SHALL GET BACK TO YOU AS SOON AS POSSIBLE.";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo "</br>";
	echo "THE RESPONSE RECORDED IS FROM THE EMAIL ID: ";
	echo $mail;
?>
<html>
<form method="GET" action="contact.html">
<br/>
<br/>
<br/>
<br/>
<br/>
<input type="submit" value="GO BACK TO HOME PAGE">
</form>